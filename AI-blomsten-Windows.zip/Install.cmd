@echo off
powershell.exe -NoProfile -File "%~dp0Install.ps1"
if errorlevel 1 (
 echo Installationen kunne ikke startes. Se LAES-MIG.txt om PowerShell-politikker.
 pause
)
