﻿param([Parameter(Mandatory=$true)][string]$Catalog,[Parameter(Mandatory=$true)][string]$Account,[Parameter(Mandatory=$true)][string]$ShareName)
$ErrorActionPreference = 'Stop'
try {
    if ($ShareName -notmatch '^AIBlomsten-[0-9-]+$') { throw 'Ugyldigt navn paa delt mappe.' }
    if (-not (Test-Path -LiteralPath (Join-Path $Catalog 'AI-blomsten-manifest.xml'))) { throw 'Manifestet mangler.' }
    $existing = Get-SmbShare -Name $ShareName -ErrorAction SilentlyContinue
    if ($existing) {
        if ($existing.Path -ne $Catalog) { throw 'Navnet bruges allerede af en anden mappe.' }
        $access = @(Get-SmbShareAccess -Name $ShareName)
        if ($access.Count -ne 1 -or $access[0].AccountName -ne $Account -or $access[0].AccessControlType -ne 'Allow' -or $access[0].AccessRight -ne 'Read') { throw 'Eksisterende deling har andre adgangsrettigheder. Den er ikke aendret.' }
    } else {
        $null = New-SmbShare -Name $ShareName -Path $Catalog -ReadAccess $Account -FolderEnumerationMode AccessBased
    }
    exit 0
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    $null = Read-Host 'Tryk Enter'
    exit 1
}
