﻿$ErrorActionPreference = 'Stop'
try {
    Write-Host 'AI-blomsten - lokal Windows-testinstallation' -ForegroundColor Cyan
    Write-Host 'Luk Word foer installation. Opsaetningen kraever lokal administratorgodkendelse.'
    if (Get-Process WINWORD -ErrorAction SilentlyContinue) { throw 'Luk Word, og start installationen igen.' }
    $siteText = (Read-Host 'Indtast hjemmesidens offentlige HTTPS-adresse').Trim()
    $site = $null
    if (-not [Uri]::TryCreate($siteText, [UriKind]::Absolute, [ref]$site) -or $site.Scheme -ne 'https' -or $site.UserInfo) { throw 'Indtast en gyldig HTTPS-adresse uden loginoplysninger.' }
    $builder = [UriBuilder]::new($site)
    $builder.Query = ''; $builder.Fragment = ''
    $builder.Path = $builder.Path -replace '/(?:index|word)\.html$', '/' 
    $source = $builder.Uri.AbsoluteUri.TrimEnd('/') + '/word.html'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $response = Invoke-WebRequest -Uri $source -UseBasicParsing -TimeoutSec 30
    if ($response.Content -notmatch 'insertInlinePictureFromBase64') { throw 'Word-versionen blev ikke fundet. Upload word.html til hjemmesiden foerst.' }
    $account = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $shareName = 'AIBlomsten-' + ($sid -replace '^S-1-5-', '')
    $catalog = Join-Path $env:LOCALAPPDATA 'AI-blomsten\catalog'
    $null = New-Item -ItemType Directory -Path $catalog -Force
    [xml]$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest-skabelon.xml') -Raw
    $ns = [Xml.XmlNamespaceManager]::new($manifest.NameTable)
    $ns.AddNamespace('o', 'http://schemas.microsoft.com/office/appforoffice/1.1')
    $manifest.SelectSingleNode('//o:SourceLocation', $ns).SetAttribute('DefaultValue', $source)
    $manifestPath = Join-Path $catalog 'AI-blomsten-manifest.xml'
    $manifest.Save($manifestPath)
    $shareHelper = Join-Path $PSScriptRoot 'Create-Share.ps1'
    foreach ($argument in @($shareHelper, $catalog, $account, $shareName)) {
        if ($argument.Contains('"')) { throw 'Opsaetningen kan ikke bruge et navn med anfoerselstegn.' }
    }
    Write-Host 'Windows beder nu om administratorgodkendelse til en mappe delt kun med din bruger.'
    $arguments = '-NoProfile -File "{0}" -Catalog "{1}" -Account "{2}" -ShareName "{3}"' -f $shareHelper, $catalog, $account, $shareName
    $process = Start-Process powershell.exe -Verb RunAs -ArgumentList $arguments -Wait -PassThru
    if ($process.ExitCode -ne 0) { throw 'Mappen kunne ikke deles. Installationen er ikke fuldfoert.' }
    $unc = '\\' + $env:COMPUTERNAME + '\' + $shareName
    if (-not (Test-Path -LiteralPath ($unc + '\AI-blomsten-manifest.xml'))) { throw 'Den delte mappe er ikke tilgaengelig. Word-kataloget er ikke registreret.' }
    $key = 'HKCU:\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\{0c3eb4bb-12a9-49e3-a6e4-72d5c99a9cc4}'
    $existing = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
    if ($existing -and $existing.Url -ne $unc) { throw 'Et andet katalog bruger installationens ID. Det er ikke blevet overskrevet.' }
    $null = New-Item -Path $key -Force
    $null = New-ItemProperty -Path $key -Name Id -Value '{0c3eb4bb-12a9-49e3-a6e4-72d5c99a9cc4}' -PropertyType String -Force
    $null = New-ItemProperty -Path $key -Name Url -Value $unc -PropertyType String -Force
    $null = New-ItemProperty -Path $key -Name Flags -Value 1 -PropertyType DWord -Force
    Write-Host 'Opsaetningen er klar.' -ForegroundColor Green
    Write-Host 'Aabn Word > Hjem > Tilfoejelsesprogrammer > Avanceret > Delt mappe.'
    Write-Host 'Vaelg AI-blomsten, og klik Tilfoej. Dette sidste klik foretages i Word.'
} catch {
    Write-Host ('Installation stoppet: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Ingen Office-sikkerhedspolitikker er blevet aendret.'
}
$null = Read-Host 'Tryk Enter for at lukke'
